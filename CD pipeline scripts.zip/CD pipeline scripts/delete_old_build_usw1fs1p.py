import paramiko
import os
import time
import sys


### FS2 IP - "10.52.91.137"

hosts = ["10.51.26.24"]
user = "ec2-user" 
privateKey = "C:\\Pradeep\\FS\\Task\\Task-Cloud\\stage-voice.pem" 
port = 22
remotePath = "/usr/local/genesys/fs"
#commandsList = ['cd /home/ec2-user',
#'bash startFS.sh']
commandsList = ['cd /home/ec2-user',
 'sudo rm -rf release fs-release.zip']


def CopyAndRun(host, commands):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    key = paramiko.RSAKey.from_private_key_file(privateKey)
    print("connecting to "+ host +" SSH .... ")
    ssh.connect(hostname=host, username=user, pkey=key)
    print("Connected to "+ host +" SSH !!!")
    for command in commands:
        print ("Executing {}".format( command ) )
        #print "Executing {}"
        stdin , stdout, stderr = ssh.exec_command(command)
        print (stdout.read())
        print ("Errors")
        print (stderr.read())
    # chan = ssh.invoke_shell()
    # chan.send('cd /usr/local/genesys/fs')
    # print 'In FS installed path'
    # chan.send('mkdir pradeep')
    ssh.close()

for host in hosts:
    CopyAndRun(host, commandsList)
sys.exit(0)
