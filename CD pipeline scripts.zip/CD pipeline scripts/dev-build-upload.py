import paramiko
import os
import time


### FS2 IP - "10.52.91.137"

hosts = ["10.52.92.172","10.52.91.137"]
user = "ec2-user" 
privateKey = "C:\\Pradeep\\FS\\Task\\Task-Cloud\\stage-voice.pem" 
port = 22
#localPath = "C:\\Pradeep\\FS\\Task\\Task-Cloud\\voicemail-8.1.202.20-mbx-pwdhash-b2.zip" 
#fname = "voicemail-8.1.202.20-mbx-pwdhash-b2.zip"
localPath = "C:\\curl\\fs-release.zip"
fname = "fs-release.zip"
remotePath = "/home/ec2-user/"


def CopyAndRun(host):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    key = paramiko.RSAKey.from_private_key_file(privateKey)
    print("connecting to "+ host +" SSH .... ")
    ssh.connect(hostname=host, username=user, pkey=key)
    print("Connected to "+ host +" SSH !!!")
    print(time.ctime())
    print("connecting to "+ host +" SFTP .... ")
    transport = paramiko.Transport((host, port))
    transport.connect(username=user, pkey=key)
    sftp = paramiko.SFTPClient.from_transport(transport)
    print("Connected to "+ host +" SFTP !!!\n")

    try:
        sftp.chdir(remotePath)
    except IOError:
        sftp.mkdir(remotePath)
        sftp.chdir(remotePath)
    sftp.put(localPath, os.path.join(remotePath, fname))
    print(time.ctime())
    sftp.close()

    ssh.close()

for host in hosts:
    CopyAndRun(host)
